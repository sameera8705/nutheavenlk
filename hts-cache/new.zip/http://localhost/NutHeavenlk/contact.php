<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Contact Us | Nut Heaven.lk</title>
<meta name="description" content="Premium cashews by Nut Heaven.lk">
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<header class="site-header">
  <div class="nav-wrap">
    <a class="brand" href="index.php"><img src="assets/images/logo-premium.png" alt="Nut Heaven.lk logo"></a>
    <button class="menu-toggle" aria-label="Open menu">☰</button>
    <nav class="main-nav">
      <a class="" href="index.php">Home</a>
      <a class="" href="about.php">About Us</a>
      <a class="" href="products.php">Products</a>
      <a class="active" href="contact.php">Contact Us</a>
      <a class="cart-link " href="cart.php">Cart <span>0</span></a>
    </nav>
  </div>
</header>
<main>
<section class="page-hero"><div class="eyebrow">Get in Touch</div><h1>Contact Us</h1><p>Questions about products, orders or wholesale enquiries? Send us a message.</p></section>
<section class="section"><div class="two-col"><div class="luxury-panel"><h3>Nut Heaven.lk</h3><p><strong>Email</strong><br><a href="mailto:nutheavenlk@gmail.com">nutheavenlk@gmail.com</a></p><p><strong>Orders</strong><br>Online ordering is available 24/7 through this website.</p><p><strong>Payment</strong><br>Bank transfer is the initial payment method. A receipt is uploaded at checkout for order verification.</p></div>
<div><form method="post"><input type="hidden" name="csrf" value="c4fdfc2c4b6d2690011d43557f4e43b082b22f7c90269219d0bb61cfe1afc1d9"><div class="form-grid"><div class="field"><label>Name *</label><input name="name" required></div><div class="field"><label>Email *</label><input type="email" name="email" required></div><div class="field full"><label>Subject</label><input name="subject"></div><div class="field full"><label>Message *</label><textarea name="message" rows="7" required></textarea></div><div class="field full"><button class="btn gold" type="submit">Send Message</button></div></div></form></div></div></section>

</main>
<footer class="footer">
  <div class="footer-grid">
    <div><h3>Nut Heaven.lk</h3><p>Premium cashews, beautifully prepared and presented with timeless elegance.</p></div>
    <div><h4>Explore</h4><a href="about.php">About Us</a><a href="products.php">Products</a><a href="contact.php">Contact Us</a></div>
    <div><h4>Contact</h4><a href="mailto:nutheavenlk@gmail.com">nutheavenlk@gmail.com</a><p>Orders are accepted online 24/7.</p></div>
  </div>
  <div class="footer-bottom">© 2026 Dream S Media. All rights reserved.</div>
</footer>
<script src="assets/js/app.js"></script>
</body></html>
