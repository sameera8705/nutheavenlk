<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Your Cart | Nut Heaven.lk</title>
<meta name="description" content="Premium cashews by Nut Heaven.lk">
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<header class="site-header">
  <div class="nav-wrap">
    <a class="brand" href="index.php"><img src="assets/images/logo-premium.png" alt="Nut Heaven.lk logo"></a>
    <button class="menu-toggle" aria-label="Open menu">☰</button>
    <nav class="main-nav">
      <a class="" href="index.php">Home</a>
      <a class="" href="about.php">About Us</a>
      <a class="" href="products.php">Products</a>
      <a class="" href="contact.php">Contact Us</a>
      <a class="cart-link active" href="cart.php">Cart <span>0</span></a>
    </nav>
  </div>
</header>
<main>
<section class="page-hero"><div class="eyebrow">Your Selection</div><h1>Shopping Cart</h1><p>Review your products before checkout.</p></section>
<section class="section"><div class="empty"><h2>Your cart is empty.</h2><p>Explore the collection and add your favourite cashews.</p><a class="btn gold" href="products.php">Browse Products</a></div></section>
</main>
<footer class="footer">
  <div class="footer-grid">
    <div><h3>Nut Heaven.lk</h3><p>Premium cashews, beautifully prepared and presented with timeless elegance.</p></div>
    <div><h4>Explore</h4><a href="about.php">About Us</a><a href="products.php">Products</a><a href="contact.php">Contact Us</a></div>
    <div><h4>Contact</h4><a href="mailto:nutheavenlk@gmail.com">nutheavenlk@gmail.com</a><p>Orders are accepted online 24/7.</p></div>
  </div>
  <div class="footer-bottom">© 2026 Dream S Media. All rights reserved.</div>
</footer>
<script src="assets/js/app.js"></script>
</body></html>
