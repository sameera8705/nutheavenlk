<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Products | Nut Heaven.lk</title>
<meta name="description" content="Premium cashews by Nut Heaven.lk">
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<header class="site-header">
  <div class="nav-wrap">
    <a class="brand" href="index.php"><img src="assets/images/logo-premium.png" alt="Nut Heaven.lk logo"></a>
    <button class="menu-toggle" aria-label="Open menu">☰</button>
    <nav class="main-nav">
      <a class="" href="index.php">Home</a>
      <a class="" href="about.php">About Us</a>
      <a class="active" href="products.php">Products</a>
      <a class="" href="contact.php">Contact Us</a>
      <a class="cart-link " href="cart.php">Cart <span>0</span></a>
    </nav>
  </div>
</header>
<main>
<section class="page-hero"><div class="eyebrow">The Collection</div><h1>Premium Cashews</h1><p>Choose your favourite variety and add it to your basket.</p></section>
<section class="section"><div class="product-grid">
<article class="product-card"><a href="product.php?id=7"><div class="product-image"><img src="assets/images/products/garlic-cashews.jpg" alt="Garlic Cashews"></div></a><div class="product-info"><h3>Garlic Cashews</h3><p>Aromatic roasted cashews with a savoury garlic finish.</p><div class="price">LKR 2,250.00</div><div class="product-actions"><button class="btn gold" data-add-cart="7">Add to Cart</button><a class="btn" href="product.php?id=7">Details</a></div></div></article><article class="product-card"><a href="product.php?id=6"><div class="product-image"><img src="assets/images/products/burnt-cashews.jpg" alt="Burnt Cashews"></div></a><div class="product-info"><h3>Burnt Cashews</h3><p>Deep-roasted cashews with an intense, caramelised character.</p><div class="price">LKR 2,200.00</div><div class="product-actions"><button class="btn gold" data-add-cart="6">Add to Cart</button><a class="btn" href="product.php?id=6">Details</a></div></div></article><article class="product-card"><a href="product.php?id=5"><div class="product-image"><img src="assets/images/products/oil-roasted-cashews.jpg" alt="Oil Roasted Cashews"></div></a><div class="product-info"><h3>Oil Roasted Cashews</h3><p>Crisp roasted cashews with a luxurious roasted flavour.</p><div class="price">LKR 2,150.00</div><div class="product-actions"><button class="btn gold" data-add-cart="5">Add to Cart</button><a class="btn" href="product.php?id=5">Details</a></div></div></article><article class="product-card"><a href="product.php?id=4"><div class="product-image"><img src="assets/images/products/salted-cashews.jpg" alt="Salted Cashews"></div></a><div class="product-info"><h3>Salted Cashews</h3><p>Classic lightly salted cashews for everyday indulgence.</p><div class="price">LKR 1,950.00</div><div class="product-actions"><button class="btn gold" data-add-cart="4">Add to Cart</button><a class="btn" href="product.php?id=4">Details</a></div></div></article><article class="product-card"><a href="product.php?id=3"><div class="product-image"><img src="assets/images/products/devilled-cashews.jpg" alt="Devilled Cashews"></div></a><div class="product-info"><h3>Devilled Cashews</h3><p>A bold Sri Lankan-inspired spicy cashew experience.</p><div class="price">LKR 2,200.00</div><div class="product-actions"><button class="btn gold" data-add-cart="3">Add to Cart</button><a class="btn" href="product.php?id=3">Details</a></div></div></article><article class="product-card"><a href="product.php?id=2"><div class="product-image"><img src="assets/images/products/oven-cashews.jpg" alt="Oven Cashews"></div></a><div class="product-info"><h3>Oven Cashews</h3><p>Slow-roasted cashews with a rich, naturally golden finish.</p><div class="price">LKR 2,100.00</div><div class="product-actions"><button class="btn gold" data-add-cart="2">Add to Cart</button><a class="btn" href="product.php?id=2">Details</a></div></div></article><article class="product-card"><a href="product.php?id=1"><div class="product-image"><img src="assets/images/products/raw-cashews.jpg" alt="Raw Cashews"></div></a><div class="product-info"><h3>Raw Cashews</h3><p>Premium raw cashews, carefully selected for freshness and quality.</p><div class="price">LKR 1,850.00</div><div class="product-actions"><button class="btn gold" data-add-cart="1">Add to Cart</button><a class="btn" href="product.php?id=1">Details</a></div></div></article></div></section>

</main>
<footer class="footer">
  <div class="footer-grid">
    <div><h3>Nut Heaven.lk</h3><p>Premium cashews, beautifully prepared and presented with timeless elegance.</p></div>
    <div><h4>Explore</h4><a href="about.php">About Us</a><a href="products.php">Products</a><a href="contact.php">Contact Us</a></div>
    <div><h4>Contact</h4><a href="mailto:nutheavenlk@gmail.com">nutheavenlk@gmail.com</a><p>Orders are accepted online 24/7.</p></div>
  </div>
  <div class="footer-bottom">© 2026 Dream S Media. All rights reserved.</div>
</footer>
<script src="assets/js/app.js"></script>
</body></html>
