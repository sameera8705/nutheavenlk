<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>About Us | Nut Heaven.lk</title>
<meta name="description" content="Premium cashews by Nut Heaven.lk">
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<header class="site-header">
  <div class="nav-wrap">
    <a class="brand" href="index.php"><img src="assets/images/logo-premium.png" alt="Nut Heaven.lk logo"></a>
    <button class="menu-toggle" aria-label="Open menu">☰</button>
    <nav class="main-nav">
      <a class="" href="index.php">Home</a>
      <a class="active" href="about.php">About Us</a>
      <a class="" href="products.php">Products</a>
      <a class="" href="contact.php">Contact Us</a>
      <a class="cart-link " href="cart.php">Cart <span>0</span></a>
    </nav>
  </div>
</header>
<main>
<section class="page-hero"><div class="eyebrow">Our Story</div><h1>About Nut Heaven.lk</h1><p>A premium cashew experience built around quality, presentation and simple online ordering.</p></section>
<section class="section"><div class="two-col">
<div><div class="eyebrow">More than a snack</div><h2 style="font:600 50px 'Cormorant Garamond',serif;color:#efd69c;margin:10px 0">A refined take on a timeless favourite.</h2>
<p>Nut Heaven.lk is a premium cashew brand concept created to bring together carefully prepared cashews and a sophisticated customer experience.</p>
<p>From classic raw and salted varieties to bold devilled, garlic and roasted flavours, our collection is designed for everyday enjoyment, gifting and sharing.</p>
<p>We believe premium food should feel premium at every touchpoint — from the first impression of the packaging to the moment you open the pack.</p></div>
<div class="luxury-panel"><h3>Our Promise</h3><p><strong>Quality:</strong> We present every product with a quality-first mindset.</p><p><strong>Elegance:</strong> A black-and-gold visual identity inspired by European luxury brands.</p><p><strong>Convenience:</strong> Simple cart, checkout and bank-transfer receipt upload.</p><p><strong>Care:</strong> Customer order details are handled through a structured order workflow.</p></div>
</div></section>

</main>
<footer class="footer">
  <div class="footer-grid">
    <div><h3>Nut Heaven.lk</h3><p>Premium cashews, beautifully prepared and presented with timeless elegance.</p></div>
    <div><h4>Explore</h4><a href="about.php">About Us</a><a href="products.php">Products</a><a href="contact.php">Contact Us</a></div>
    <div><h4>Contact</h4><a href="mailto:nutheavenlk@gmail.com">nutheavenlk@gmail.com</a><p>Orders are accepted online 24/7.</p></div>
  </div>
  <div class="footer-bottom">© 2026 Dream S Media. All rights reserved.</div>
</footer>
<script src="assets/js/app.js"></script>
</body></html>
