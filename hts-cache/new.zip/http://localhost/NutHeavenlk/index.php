<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Nut Heaven.lk | Premium Cashews</title>
<meta name="description" content="Premium cashews from Nut Heaven.lk. Shop our signature Sri Lankan cashew collection.">
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<header class="site-header">
  <div class="nav-wrap">
    <a class="brand" href="index.php"><img src="assets/images/logo-premium.png" alt="Nut Heaven.lk logo"></a>
    <button class="menu-toggle" aria-label="Open menu">☰</button>
    <nav class="main-nav">
      <a class="active" href="index.php">Home</a>
      <a class="" href="about.php">About Us</a>
      <a class="" href="products.php">Products</a>
      <a class="" href="contact.php">Contact Us</a>
      <a class="cart-link " href="cart.php">Cart <span>0</span></a>
    </nav>
  </div>
</header>
<main>
<section class="hero"><div class="slides">
<div class="slide active" style="background-image:url('assets/images/banners/banner-1.jpg')"><div class="slide-content"><div class="eyebrow">Nut Heaven.lk • Premium Collection</div><div class="hero-rule"></div><h1>The Art of Premium Cashews</h1><p>Hand-selected. Beautifully prepared. Made to be remembered.</p><a class="btn gold" href="products.php">Shop the Collection</a></div></div>
<div class="slide " style="background-image:url('assets/images/banners/banner-2.jpg')"><div class="slide-content"><div class="eyebrow">Nut Heaven.lk • Premium Collection</div><div class="hero-rule"></div><h1>A Little Luxury in Every Bite</h1><p>Discover our signature roasted, seasoned and classic cashew range.</p><a class="btn gold" href="products.php">Shop the Collection</a></div></div>
<div class="slide " style="background-image:url('assets/images/banners/banner-3.jpg')"><div class="slide-content"><div class="eyebrow">Nut Heaven.lk • Premium Collection</div><div class="hero-rule"></div><h1>Crafted for Your Table</h1><p>Premium Sri Lankan cashews, presented with timeless elegance.</p><a class="btn gold" href="products.php">Shop the Collection</a></div></div>
<div class="slider-nav"><button class="dot active" aria-label="Slide 1"></button><button class="dot " aria-label="Slide 2"></button><button class="dot " aria-label="Slide 3"></button></div>
<div class="slider-arrows"><button data-prev aria-label="Previous">←</button><button data-next aria-label="Next">→</button></div></div></section>
<section class="section">
<div class="section-head"><div class="eyebrow">The Nut Heaven Standard</div><h2>Luxury, from the first look to the last bite.</h2><div class="gold-line"></div><p>Designed around premium presentation and an effortless shopping experience, Nut Heaven.lk brings carefully prepared cashews to your table.</p></div>
<div class="feature-grid">
<div class="feature-card"><div class="icon">✦</div><h3>Premium Selection</h3><p>Curated cashew varieties with an elegant, quality-first presentation.</p></div>
<div class="feature-card"><div class="icon">◇</div><h3>Made for Gifting</h3><p>A refined visual experience that makes every pack feel special.</p></div>
<div class="feature-card"><div class="icon">✓</div><h3>Easy Online Orders</h3><p>Add products to your cart, upload your bank-transfer receipt and track your order status.</p></div>
</div>
</section>

<section class="section" style="padding-top:0">
<div class="section-head"><div class="eyebrow">Signature Range</div><h2>Our Cashew Collection</h2><div class="gold-line"></div></div>
<div class="product-grid">
<article class="product-card"><a href="product.php?id=7"><div class="product-image"><img src="assets/images/products/garlic-cashews.jpg" alt="Garlic Cashews"></div></a><div class="product-info"><h3>Garlic Cashews</h3><p>Aromatic roasted cashews with a savoury garlic finish.</p><div class="price">LKR 2,250.00</div><div class="product-actions"><button class="btn gold" data-add-cart="7">Add to Cart</button><a class="btn" href="product.php?id=7">View</a></div></div></article><article class="product-card"><a href="product.php?id=6"><div class="product-image"><img src="assets/images/products/burnt-cashews.jpg" alt="Burnt Cashews"></div></a><div class="product-info"><h3>Burnt Cashews</h3><p>Deep-roasted cashews with an intense, caramelised character.</p><div class="price">LKR 2,200.00</div><div class="product-actions"><button class="btn gold" data-add-cart="6">Add to Cart</button><a class="btn" href="product.php?id=6">View</a></div></div></article><article class="product-card"><a href="product.php?id=5"><div class="product-image"><img src="assets/images/products/oil-roasted-cashews.jpg" alt="Oil Roasted Cashews"></div></a><div class="product-info"><h3>Oil Roasted Cashews</h3><p>Crisp roasted cashews with a luxurious roasted flavour.</p><div class="price">LKR 2,150.00</div><div class="product-actions"><button class="btn gold" data-add-cart="5">Add to Cart</button><a class="btn" href="product.php?id=5">View</a></div></div></article><article class="product-card"><a href="product.php?id=4"><div class="product-image"><img src="assets/images/products/salted-cashews.jpg" alt="Salted Cashews"></div></a><div class="product-info"><h3>Salted Cashews</h3><p>Classic lightly salted cashews for everyday indulgence.</p><div class="price">LKR 1,950.00</div><div class="product-actions"><button class="btn gold" data-add-cart="4">Add to Cart</button><a class="btn" href="product.php?id=4">View</a></div></div></article><article class="product-card"><a href="product.php?id=3"><div class="product-image"><img src="assets/images/products/devilled-cashews.jpg" alt="Devilled Cashews"></div></a><div class="product-info"><h3>Devilled Cashews</h3><p>A bold Sri Lankan-inspired spicy cashew experience.</p><div class="price">LKR 2,200.00</div><div class="product-actions"><button class="btn gold" data-add-cart="3">Add to Cart</button><a class="btn" href="product.php?id=3">View</a></div></div></article><article class="product-card"><a href="product.php?id=2"><div class="product-image"><img src="assets/images/products/oven-cashews.jpg" alt="Oven Cashews"></div></a><div class="product-info"><h3>Oven Cashews</h3><p>Slow-roasted cashews with a rich, naturally golden finish.</p><div class="price">LKR 2,100.00</div><div class="product-actions"><button class="btn gold" data-add-cart="2">Add to Cart</button><a class="btn" href="product.php?id=2">View</a></div></div></article><article class="product-card"><a href="product.php?id=1"><div class="product-image"><img src="assets/images/products/raw-cashews.jpg" alt="Raw Cashews"></div></a><div class="product-info"><h3>Raw Cashews</h3><p>Premium raw cashews, carefully selected for freshness and quality.</p><div class="price">LKR 1,850.00</div><div class="product-actions"><button class="btn gold" data-add-cart="1">Add to Cart</button><a class="btn" href="product.php?id=1">View</a></div></div></article></div>
</section>
<a class="whatsapp" href="https://wa.me/?text=Hello%20Nut%20Heaven.lk%2C%20I%20would%20like%20to%20order%20cashews." target="_blank">WhatsApp Order</a>

</main>
<footer class="footer">
  <div class="footer-grid">
    <div><h3>Nut Heaven.lk</h3><p>Premium cashews, beautifully prepared and presented with timeless elegance.</p></div>
    <div><h4>Explore</h4><a href="about.php">About Us</a><a href="products.php">Products</a><a href="contact.php">Contact Us</a></div>
    <div><h4>Contact</h4><a href="mailto:nutheavenlk@gmail.com">nutheavenlk@gmail.com</a><p>Orders are accepted online 24/7.</p></div>
  </div>
  <div class="footer-bottom">© 2026 Dream S Media. All rights reserved.</div>
</footer>
<script src="assets/js/app.js"></script>
</body></html>
